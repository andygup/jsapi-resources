<script setup>
import Scatterplot from "./components/Scatterplot.vue";
</script>

<template>
  <Scatterplot />
</template>
