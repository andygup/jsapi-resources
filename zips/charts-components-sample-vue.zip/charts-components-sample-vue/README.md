# Charts components Vue using Vite sample (beta)

This sample is for getting started developing with Vue 3 in Vite. The sample uses Vue 3 `<script setup>` Single-File Components, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

## Get Started

Run `npm install` and then start adding modules.

For a list of all available `npm` commands see `scripts` in `package.json`, e.g. `npm run build`.
