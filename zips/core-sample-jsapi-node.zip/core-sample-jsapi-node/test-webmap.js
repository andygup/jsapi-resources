#!/usr/bin/env node

require("./public/webmap");
