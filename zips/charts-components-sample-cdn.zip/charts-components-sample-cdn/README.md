# Charts components CDN sample (beta)

Testing test