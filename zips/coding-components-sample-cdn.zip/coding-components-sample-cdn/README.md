# Coding components CDN sample

Since the ArcGIS Maps SDK for JavaScript and Calcite Components are dependencies of Coding Components they have to be loaded first. Coding Components will detect that it is used under AMD and will require its Maps SDK dependencies using the AMD module loader.
